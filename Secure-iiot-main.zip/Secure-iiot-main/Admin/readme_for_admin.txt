Hi here we will update how you can setup the admin file directory
