Hi here we will update how to setup the directory for superadmin user
